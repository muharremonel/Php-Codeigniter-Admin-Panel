<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>
    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/navheader'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider haberler-bg">
    </div>
    <!-- Header End -->

    <!-- Haberler Hepsi -->

    <section class="container" style="margin-top: -240px;">
        <div class="text-center mb-5">
            <h1><?php echo $this->lang->line('gundem_duyurular'); ?></h1>
        </div>

        <div class="row">
            <?php foreach ($duyuru as $value) { ?>
                <div class="col-md-4 p-4">
                    <div class="card shadow img-ms">
                        <div class="card-body text-center" style="height: 500px;">
                            <a href="<?php echo base_url('duyurudetay/' . $value['slug']); ?>">
                                <?php if (!@$value['gorsel1']) { ?>
                                    <img src="<?php echo base_url('assets/front/'); ?>img/background/haberler.png" class="img-ms" style="height: 250px; width: 100%;" alt="">
                                <?php } else { ?>
                                    <img src="<?php echo base_url($value['gorsel1']); ?>" class="img-ms" style="height: 250px; width: 100%;" alt="">
                                <?php } ?>
                                <div class="card-body p-2">
                                    <h5 class="mt-4"><?php echo $value['anabaslik']; ?></h5>
                                    <p class="text-dark"><?php echo $value['summary']; ?></p>
                                </div>
                            </a>
                        </div>
                        <div class="text-end mb-4 p-2" style="bottom: 0%;">
                            <a href="<?php echo base_url('duyurudetay/' . $value['slug']); ?>" class="haber-read-green"><?php echo $this->lang->line('gundem_dahafazla'); ?> <img src="<?php echo base_url('assets/front/'); ?>img/icon/haber.png" class="px-2" alt=""></a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- Haberler Hepsi Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>