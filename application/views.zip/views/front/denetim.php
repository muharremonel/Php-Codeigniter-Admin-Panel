<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/header'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid abo-slider mb-5" style="background-image:url('<?php echo base_url('assets/front/'); ?>img/background/about-slider.png');">
    </div>
    <!-- Header End -->

    <!-- Heyet -->
    <section>
        <div class="container" style="margin-top: -220px;">
            <div class="row">
                <?php foreach ($denetim as $value) { ?>
                    <div class="col-md-3 p-3 mb-3 heyet-pad">
                        <div class="card p-2 shadow roundes">
                            <div class="card-body mb-4" style="height: 220px;">
                                <img src="<?php echo base_url($value['gorsel']); ?>" class="team-man" style="height: 220px;" alt="">
                            </div>
                            <div class="card-body text-center">
                                <h5><?php echo $value['name']; ?></h5>
                                <div class="d-flex mt-3 p-2 heyet-cont justify-content-center">
                                    <a href="<?php echo $value['facebook']; ?>" class="m-2"><img src="<?php echo base_url('assets/front/'); ?>img/icon/team-facebook.png" alt=""></a>
                                    <a href="<?php echo $value['twitter']; ?>" class="m-2"><img src="<?php echo base_url('assets/front/'); ?>img/icon/team-twitter.png" alt=""></a>
                                    <a href="<?php echo $value['instagram']; ?>" class="m-2"><img src="<?php echo base_url('assets/front/'); ?>img/icon/team-instagram.png" alt=""></a>
                                    <a href="<?php echo $value['linkedin']; ?>" class="m-2"><img src="<?php echo base_url('assets/front/'); ?>img/icon/team-linkedin.png" alt=""></a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- Heyet Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>