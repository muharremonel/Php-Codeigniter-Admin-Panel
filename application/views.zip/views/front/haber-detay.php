<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/navheader'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider haberler-bg">
        <div class="text-center p-4">
            <div class="mt-5 col-md-8" style="margin: auto;">
                <h1><?php echo $haber['anabaslik']; ?></h1>
            </div>
            <div class="mb-5">
                <span class="px-3"><?php echo $haber['name']; ?></span>
                <span><?php echo $haber['date']; ?></span>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- Haberler -->
    <section class="container">
        <div class="haber-top">
            <div class="col-md-9 mb-5" style="margin: auto;">
                <a data-fancybox="gallery" href="<?php echo base_url($haber['gorsel1']); ?>">
                    <img src="<?php echo base_url($haber['gorsel1']); ?>" class="img-sizeg img-ms" style="height: 500px;" alt="">
                </a>
            </div>

        </div>
    </section>
    <!-- Haberler Son -->

    <!-- Haberler Hepsi -->

    <section class="container mb-5">
        <div class="text-center container col-md-11" style="margin: auto;">
            <?php echo $haber['content']; ?>
        </div>
    </section>

    <section class="container">
        <div class="row">
            <div class="col-md-4 p-4">
                <?php if (!@$haber['gorsel2']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($haber['gorsel2']); ?>">
                        <img src="<?php echo base_url($haber['gorsel2']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
            <div class="col-md-4 p-4">
                <?php if (!@$haber['gorsel3']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($haber['gorsel2']); ?>">
                        <img src="<?php echo base_url($haber['gorsel3']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
            <div class="col-md-4 p-4">
                <?php if (!@$haber['gorsel4']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($haber['gorsel2']); ?>">
                        <img src="<?php echo base_url($haber['gorsel4']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- Haberler Hepsi Son -->



    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>