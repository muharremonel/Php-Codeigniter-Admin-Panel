<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/header'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider" style="background-image:url('<?php echo base_url('assets/front/'); ?>img/background/about-slider.png');">
    </div>
    <!-- Header End -->
    <?php $result = hakkimizdaconfig(); ?>
    <!-- Hakkımızda -->
    <section class="container">
        <div class="container">
            <div class="col-md-9 mb-5">
                <div class="mb-2">
                    <span><?php echo $this->lang->line('ana_about'); ?></h1>
                </div>
                <h1 class="mb-4"><?php echo $result['en_baslik'] ?></h1>
            </div>
            <div class="row mb-5">
                <div class="col-md-6 p-3" style="margin:auto;">
                    <p class="mb-4"><?php echo $result['en_hakkimizda'] ?></p>
                </div>
                <div class="col-md-6">
                    <img src="<?php echo $result['gorsel'] ?>" class="w-100 img-ms" style="height: 570px;" alt="">
                </div>
            </div>
            <!--
            <div class="text-center mb-5">
                <h1 class="ab-h1">The process we follow</h1>
            </div>
            <div class="row">
                <div class="col-md-3 card-body">
                    <img src="<?php echo base_url('assets/front/'); ?>img/icon/abo-pro.png" class="img-sizeg mb-4" alt="">
                    <h3 class="mb-2">Planning</h3>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.Lorem ipsum dolor sit
                    </p>
                </div>
                <div class="col-md-3 card-body">
                    <img src="<?php echo base_url('assets/front/'); ?>img/icon/abo-pro.png" class="img-sizeg mb-4" alt="">
                    <h3 class="mb-2">Conception</h3>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.Lorem ipsum dolor sit
                    </p>
                </div>
                <div class="col-md-3 card-body">
                    <img src="<?php echo base_url('assets/front/'); ?>img/icon/abo-pro.png" class="img-sizeg mb-4" alt="">
                    <h3 class="mb-2">Design</h3>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.Lorem ipsum dolor sit
                    </p>
                </div>
                <div class="col-md-3 card-body">
                    <img src="<?php echo base_url('assets/front/'); ?>img/icon/abo-pro.png" class="img-sizeg mb-4" alt="">
                    <h3 class="mb-2">Development</h3>
                    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.
                        Lorem ipsum dolor sit amet, consetetur sadipscing elitr.Lorem ipsum dolor sit
                    </p>
                </div>

            </div>
            -->
        </div>
    </section>

    <!-- Hakkımızda Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>