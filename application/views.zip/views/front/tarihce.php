<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/header'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider" style="background-image:url('<?php echo base_url('assets/front/'); ?>img/background/about-slider.png');">
    </div>
    <!-- Header End -->
    <!-- Tarihçe -->
    <section class="container">
        <div class="container">
            <div class="col-md-12 text-center mb-5">
                <span class="mb-5"><?php echo $this->lang->line('t_tarihce'); ?></h1>
                    <h1 class="mb-4 mt-3"><?php echo $this->lang->line('t_baslik'); ?></h1>
                    <p class="mb-4"><?php echo $this->lang->line('t_met1'); ?></p>
                    <p><?php echo $this->lang->line('t_met2'); ?></p>
                    <p class="mb-4"><?php echo $this->lang->line('t_met3'); ?></p>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h3 class="mb-4 text-center h-solgun"><?php echo $this->lang->line('t_eski'); ?>
                        <h3 />
                        <img src="<?php echo base_url('assets/front/'); ?>img/background/eski_tarihce.png" class="img-sizeg mb-5" alt="">
                </div>
                <div class="col-md-6">
                    <h3 class="mb-4 text-center h-solgun"><?php echo $this->lang->line('t_yeni'); ?>
                        <h3 />
                        <img src="<?php echo base_url('assets/front/'); ?>img/background/yeni_tarihce.png" class="img-sizeg" alt="">
                </div>

            </div>

        </div>
    </section>

    <!-- Tarihçe Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>