<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

  <!-- HEADER INCLUDE -->
  <?php $this->load->view('front/include/header'); ?>
  <!-- HEADER INCLUDE SON -->

  <!-- Ana Slider -->
  <?php $result = anaconfig(); ?>
  <section>
    <div class="swiper mySlider carousel slide">
      <div class="swiper-wrapper">
        <?php foreach ($slider as $value) { ?>
          <div class="swiper-slide">
            <img src="<?php echo base_url($value['gorsel']); ?>" class="d-block w-100 slider-gorsel" alt="...">
            <div class="slider-metin  bottom-true">
              <div class="col-md-7">
                <h1 class="slider-text mb-5"><?php echo $value['metin']; ?></h1>
              </div>
              <div class="d-flex">
                <a href="<?php echo linkto('hakkimizda') ?>" class="btn btn-gkosb-green btn-slider-gkosb">GKOSB</a>
                <div class="p-2">
                  <a href="https://www.youtube.com/watch?v=ZsR9utqbcO8&ab_channel=Gazetegebze.com.tr">
                    <img src="<?php echo base_url('assets/front/'); ?>img/icon/play-icon.svg" class="slider-text-icon" alt="">
                    <span class="slider-text-mane"><?php echo $this->lang->line('slider_video'); ?></span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>

    </div>
  </section>
  <!-- Ana Slider Son.. -->

  <!-- Kutucuklar
  <section class="container" style="z-index: 9999;">
    <div class="top-true">
      <div class="row">
        <div class="col-md-3">
          <div class="for-card card shadow align-items-center">
            <img src="<?php echo base_url('assets/front/'); ?>img/icon/1.png" class="for-card-img" alt="">
          </div>
        </div>
        <div class="col-md-3">
          <div class="for-card card shadow align-items-center">
            <img src="<?php echo base_url('assets/front/'); ?>img/icon/2.png" class="for-card-img" alt="">
          </div>
        </div>
        <div class="col-md-3">
          <div class="for-card card shadow align-items-center">
            <img src="<?php echo base_url('assets/front/'); ?>img/icon/3.png" class="for-card-img" alt="">
          </div>
        </div>
        <div class="col-md-3">
          <div class="for-card card shadow align-items-center">
            <img src="<?php echo base_url('assets/front/'); ?>img/icon/4.png" class="for-card-img" alt="">
          </div>
        </div>

      </div>
    </div>
  </section>
   Kutucuklar Son.. --->

  <!-- Hakkımızda --->
  <div class="d-flex mt-5 mb-5">
    <hr class="hr-concept" style="height: 6px;">
    <h3 class="px-2"><?php echo $this->lang->line('ana_about'); ?></h3>
  </div>
  <section class="container">
    <div class="row">
      <div class="col-lg-7" style="margin:auto;">
        <h1 class="about-ftc-bas mb-4">GLOBAL KARMA <br> ORGANİZE SANAYİ BÖLGESİ</h1>
        <p class="mb-4"><?php echo $result['en_hakkimizda'] ?></p>

        <a href="#" class="btn btn-gkosb-green btn-slider-gkosb mb-5"><?php echo $this->lang->line('ana_fazla'); ?></a>
      </div>
      <?php $result = hakkimizdaconfig(); ?>
      <div class="col-lg-5">
        <img src="<?php echo $result['gorsel'] ?>" class="about-ftc-img img-mt-" alt="">
      </div>
    </div>
    <div class="row mt-5 mb-5 align-items-center">
      <div class="col-md-2">
        <span class=""><?php echo $this->lang->line('ana_firma'); ?></span>
      </div>
      <div class="col-md-8">
        <hr class="w-100">
      </div>
      <div class="col-md-2">
        <a href="<?php echo linkto('firmalar') ?>" class="fa fa-arrow-right duyuru-link"><?php echo $this->lang->line('ana_firma_tum'); ?></a>
      </div>
    </div>
    <div class="swiper myReferans mb-5">
      <div class="swiper-wrapper swp-about">
        <?php foreach ($firma as $value) { ?>
          <div class="swiper-slide">
            <img src="<?php echo base_url($value['gorsel']); ?>" class="swp-slide-img" style="width: 200px;" alt="">
          </div>
        <?php } ?>
      </div>
    </div>
  </section>
  <!-- Hakkımızda Son.. --->

  <!-- Haberler --->
  <section>
    <div class="news-bg" style="background-image: url('<?php echo base_url('assets/front/'); ?>img/background/haberler.png');">
      <div class="container">
        <div class="col-md-6 position-absolute ms-4 haber-bas">
          <h1 class="text-white fs-lg-5 fs-md-3 fs-2"><?php echo $this->lang->line('ana_haber'); ?></h1>
        </div>
        <div class="swiper myNews m-3" style="padding-top: 72px;">
          <div class="swiper-wrapper">
            <?php foreach ($haber as $value) { ?>
              <div class="swiper-slide">
                <div class="card shadow img-ms">
                  <div class="card-body text-center" style="height: 500px;">
                    <a href="<?php echo base_url('haberdetay/' . $value['slug']); ?>">
                      <?php if (!@$value['gorsel1']) { ?>
                        <img src="<?php echo base_url('assets/front/'); ?>img/logo/a12.png" class="img-ms" style="height: 250px; width: 100%;" alt="">
                      <?php } else { ?>
                        <img src="<?php echo base_url($value['gorsel1']); ?>" class="img-ms" style="height: 250px; width: 100%;" alt="">
                      <?php } ?>
                      <div class="card-body p-2">
                        <h5 class="mt-4"><?php echo $value['anabaslik']; ?></h5>
                        <p class="text-dark "><?php echo $value['summary']; ?></p>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            <?php } ?>
          </div>
          <div class="haber-button-right position-absolute fa fa-arrow-left" style="color: #66C339; background-color: #fff; padding: 20px; border-radius: 50%; top: 0px; right: 100px;"></div>
          <div class="haber-button-left position-absolute fa fa-arrow-right" style="color: #66C339; background-color: #fff; padding: 20px; border-radius: 50%; top: 0px; right: 0;"></div>
        </div>
      </div>
    </div>
  </section>
  <!-- Haberler Son.. --->

  <!-- DUYURULAR -->
  <section>
    <div class="d-flex mt-5 mb-5">
      <hr class="hr-concept" style="height: 6px;">
      <h3 class="px-2"><?php echo $this->lang->line('ana_duyuru'); ?></h3>
    </div>
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-6">
          <h1 class="duyuru-bas"><?php echo $this->lang->line('ana_duyuru_bas'); ?></h1>
        </div>
        <div class="col-md-6">
          <a href="<?php echo linkto('duyurular') ?>" class="fa fa-arrow-right duyuru-link"><?php echo $this->lang->line('ana_duyuru_tum'); ?></a>
        </div>
      </div>
      <div class="row">
        <?php $id = 0;
        foreach ($duyuru as $value) { ?>
          <?php if ($id <= 3) { ?>
            <div class="col-md-3 mb-3">
              <a href="">
                <a href="<?php echo base_url('duyurudetay/' . $value['slug']); ?>">
                  <?php if (!@$value['gorsel1']) { ?>
                    <img src="<?php echo base_url('assets/front/'); ?>img/background/haberler.png" class="img-ms" style="height: 250px; width: 100%;" alt="">
                  <?php } else { ?>
                    <img src="<?php echo base_url($value['gorsel1']); ?>" class="img-ms" style="height: 250px; width: 100%;" alt="">
                  <?php } ?>
                  <h3 class="mb-2 mt-4"><?php echo $value['anabaslik']; ?></h3>
                  <p class="duyuru-text-p"><?php echo $value['summary']; ?></p>
                </a>
            </div>
          <?php } ?>
        <?php $id++;
        } ?>

      </div>
    </div>
  </section>
  <!-- DUYURULAR SON -->




  <!-- FOOTER INCLUDE -->
  <?php $this->load->view('front/include/footer'); ?>
  <!-- FOOTER INCLUDE SON -->

  <!-- SCRIPTS INCLUDE -->
  <?php $this->load->view('front/include/scripts'); ?>
  <!-- SCRIPTS INCLUDE SON -->

</body>

</html>