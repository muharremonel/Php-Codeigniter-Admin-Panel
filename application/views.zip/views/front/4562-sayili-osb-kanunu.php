<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>
    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/navheader'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid  abo-slider haberler-bg">
        <div class="text-center p-4">
            <div class=" mt-5">
                <h1><?php echo $this->lang->line('hd_mevzuat_1'); ?></h1>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <section class="container">
        <div class="col-md-10 mb-3" style="padding: 20px; height:100%; margin:auto;">
            <iframe src="https://online.fliphtml5.com/pqfyw/txfx/" width="100%" height="700px" class="mobil" frameborder="0"></iframe>
        </div>
        <div class="col-md-10 mb-5" style="padding: 20px; height:100%; margin:auto;">
            <a class="fa fa-arrow-right" style="text-align: center; color: #66C339;" target="blank" href="<?php echo base_url('osb_4562'); ?>">
                PDF İNDİR
            </a>
        </div>
    </section>





    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>