<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/header'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider" style="background-image:url('<?php echo base_url('assets/front/'); ?>img/background/about-slider.png');">
    </div>
    <!-- Header End -->

    <!-- Hakkımızda -->
    <section class="container">
        <div class="col-md-10 mb-5" style="margin: auto;">
            <div class="mb-2">
                <span>Global Karma Organize Sanayi Bölgesi</h1>
            </div>
            <h1 class="mb-4"><?php echo $hizmetdetay['baslik']; ?></h1>
        </div>
        <div class="col-md-10 mb-5" style="margin: auto;">
            <a data-fancybox="gallery" href="<?php echo base_url($hizmetdetay['gorsel1']); ?>">
                <img src="<?php echo base_url($hizmetdetay['gorsel1']); ?>" class="img-sizeg img-ms" style="height: 500px;" alt="">
            </a>
        </div>
    </section>

    <section class="container mb-5">
        <div class="text-center container">
            <?php echo $hizmetdetay['content']; ?>
        </div>
    </section>

    <section class="container">
        <div class="row">
            <div class="col-md-4 p-4">
                <?php if (!@$hizmetdetay['gorsel2']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($hizmetdetay['gorsel2']); ?>">
                        <img src="<?php echo base_url($hizmetdetay['gorsel2']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
            <div class="col-md-4 p-4">
                <?php if (!@$hizmetdetay['gorsel3']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($hizmetdetay['gorsel2']); ?>">
                        <img src="<?php echo base_url($hizmetdetay['gorsel3']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
            <div class="col-md-4 p-4">
                <?php if (!@$hizmetdetay['gorsel4']) { ?>
                    <a data-fancybox="gallery" href="">
                    </a>
                <?php } else { ?>
                    <a data-fancybox="gallery" href="<?php echo base_url($hizmetdetay['gorsel2']); ?>">
                        <img src="<?php echo base_url($hizmetdetay['gorsel4']); ?>" class="w-100 img-ms ftc-img-size" alt="">
                    </a>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- Hakkımızda Son -->


    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>