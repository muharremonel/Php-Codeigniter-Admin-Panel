    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->

    <?php $result = headerconfig(); ?>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-light haberler-bg sticky-top p-0 px-4 px-lg-5">
        <div class="container">
            <a href="<?php echo linkto('') ?>"><img src="<?php echo base_url($result['logo']); ?>" class="my-logo" alt=""></a>
            <button type="button" class="navbar-toggler menu-focus" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse nav-flex" id="navbarCollapse">
                <ul class="navbar-nav ml-auto p-2">
                    <li class="nav-item dropdown">
                        <a class="text-dark nav-link dropdown-toggle " role="button" data-bs-toggle="dropdown" aria-expanded="false"><?php echo $this->lang->line('hd_about'); ?></a>
                        <ul class="dropdown-menu">
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('hakkimizda') ?>"><?php echo $this->lang->line('hd_about_k'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('tarihce') ?>"><?php echo $this->lang->line('hd_tarihce'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('firmalar') ?>"><?php echo $this->lang->line('hd_firmalar'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('heyet') ?>"><?php echo $this->lang->line('ft_kurumsal_3'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('yonetim') ?>"><?php echo $this->lang->line('ft_kurumsal_4'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('denetim') ?>"><?php echo $this->lang->line('ft_kurumsal_5'); ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="text-dark nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?php echo $this->lang->line('hd_hizmet'); ?></a>
                        <ul class="dropdown-menu">
                            <?php foreach ($hizmet as $value) { ?>
                                <li><a class="text-dark dropdown-item" href="<?php echo base_url('hizmetdetay/' . $value['slug']); ?>"><?php echo $value['baslik']; ?></a></li>
                            <?php } ?>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="text-dark nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?php echo $this->lang->line('hd_mevzuat'); ?></a>
                        <ul class="dropdown-menu">
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('4562-sayili-osb-kanunu') ?>"><?php echo $this->lang->line('hd_mevzuat_1'); ?></a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo linkto('osb-uygulama-yonetmeligi') ?>"><?php echo $this->lang->line('hd_mevzuat_2'); ?></a></li>

                        </ul>
                    </li>
                    <li class="nav-item"><a href="<?php echo linkto('haberler') ?>" class="text-dark nav-link"><?php echo $this->lang->line('hd_haber'); ?></a></li>
                    <li class="nav-item"><a href="<?php echo linkto('iletisim') ?>" class="text-dark nav-link"><?php echo $this->lang->line('hd_contact'); ?></a></li>
                    <li class="nav-item dropdown">
                        <a class="text-dark nav-link dropdown-toggle " role="button" data-bs-toggle="dropdown" aria-expanded="false"><img src="<?php echo base_url('assets/front/'); ?>img/icon/flash.svg" class="nav-icon" alt=""></a>
                        <ul class="dropdown-menu">
                            <li><a class="text-dark dropdown-item" target="blank" href="http://elk.komurosb.org.tr/login.aspx"><?php echo $this->lang->line('hd_elektrik'); ?></a></li>
                        </ul>
                    </li>
                    <li class="btn-group">
                        <a class="text-dark nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false"><img src="<?php echo base_url('assets/front/'); ?>img/icon/language.svg" class="nav-icon" alt=""></a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="text-dark dropdown-item" href="<?php echo base_url('dil/dildegistir/tr'); ?>">Turkish</a></li>
                            <li><a class="text-dark dropdown-item" href="<?php echo base_url('dil/dildegistir/en'); ?>">English</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->