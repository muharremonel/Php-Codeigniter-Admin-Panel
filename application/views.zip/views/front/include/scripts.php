    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url('assets/front/'); ?>lib/wow/wow.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
    <script src="<?php echo base_url('assets/front/'); ?>lib/easing/easing.min.js"></script>
    <script src="<?php echo base_url('assets/front/'); ?>lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo base_url('assets/front/'); ?>lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo base_url('assets/front/'); ?>lib/counterup/counterup.min.js"></script>

    <!--   Anasayfa Referans Slider   -->
    <script>
        var swiper = new Swiper(".myReferans", {
            slidesPerView: 2,
            spaceBetween: 10,
            breakpoints: {
                640: {
                    slidesPerView: 2,
                    spaceBetween: 15,
                },
                768: {
                    slidesPerView: 4,
                    spaceBetween: 40,
                },
                1024: {
                    slidesPerView: 6,
                    spaceBetween: 40,
                },
            },
        });
    </script>
    <!--   Anasayfa Referans Slider Son..   -->
    <!--   FANCYBOX..   -->
    <script>
        Fancybox.bind('[data-fancybox="gallery"]', {
            dragToClose: false,

            Toolbar: false,
            closeButton: "top",

            Image: {
                zoom: false,
            },

            on: {
                initCarousel: (fancybox) => {
                    const slide = fancybox.Carousel.slides[fancybox.Carousel.page];

                    fancybox.$container.style.setProperty(
                        "--bg-image",
                        `url("${slide.$thumb.src}")`
                    );
                },
                "Carousel.change": (fancybox, carousel, to, from) => {
                    const slide = carousel.slides[to];

                    fancybox.$container.style.setProperty(
                        "--bg-image",
                        `url("${slide.$thumb.src}")`
                    );
                },
            },
        });
    </script>
    <!--   FANCYBOX SON..   -->
    <!--   Anasayfa Haberler Slider   -->
    <script>
        var swiper = new Swiper(".myNews", {
            slidesPerView: 1,
            slidesPerGroup: 1,
            spaceBetween: 10,
            loop: true,
            responsiveClass: true,
            loopFillGroupWithBlank: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: ".haber-button-left",
                prevEl: ".haber-button-right",
            },
            breakpoints: {
                500: {
                    slidesPerView: 2,
                    spaceBetween: 20,
                },
                768: {
                    slidesPerView: 2,
                    spaceBetween: 40,
                },
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 40,
                },
            },
        });
    </script>
    <!--   Anasayfa Haberler Slider Son...  -->
    <!--   Anasayfa Slider   -->
    <script>
        var swiper = new Swiper(".mySlider", {
            autoplay: {
                delay: 4000,
            },
            responsiveClass: true,
            loopFillGroupWithBlank: true,
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });
    </script>
    <!--   Anasayfa Slider Son...  -->
    <!--  Çerezler Script  -->
    <script src="<?php echo base_url('assets/front/'); ?>js/cerez.js"></script>
    <script>
        window.addEventListener("load", function() {
            window.cookieconsent.initialise({
                "palette": {
                    "popup": {
                        "background": "#646478", // şerit arkaplan rengi
                        "text": "#ffffff" // şerit üzerindeki yazı rengi
                    },
                    "button": {
                        "background": "#8ec760", // buton arkaplan rengi - "transparent" kullanıp border açabilirsiniz.
                        //"border": "#14a7d0", arkaplan rengini transparent yapıp çerçeve kullanabilirsini
                        "text": "#ffffff" // buton yazı rengi
                    }
                },
                "theme": "classic", // kullanabileceğiniz temalar block, edgeless, classic
                // "type": "opt-out", gizle uyarısını aktif etmek için
                // "position": "top", aktif ederseniz uyarı üst kısımda görünür
                // "position": "top", "static": true, aktif ederseniz uyarı üst kısımda sabit olarak görünür
                "position": "bottom-left",
                //"position": "bottom-right", aktif ederseniz uyarı sağda görünür

                "content": {
                    "message": "Sitemizden en iyi şekilde faydalanabilmeniz için çerezler kullanılmaktadır. Bu siteye giriş yaparak çerez kullanımını kabul etmiş sayılıyorsunuz.",
                    "dismiss": "Tamam",
                    "link": "Daha fazla bilgi",
                    "href": "https://globalosb.org.tr/cerezler"
                }
            })
        });
    </script>
    <!--   Çerezler Script Son...   -->

    <!-- Template Javascript -->
    <script src="<?php echo base_url('assets/front/'); ?>js/main.js"></script>