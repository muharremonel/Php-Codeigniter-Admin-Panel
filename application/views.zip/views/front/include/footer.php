    <!-- Footer Start -->
    <?php $result = footerconfig(); ?>
    <div class="container-fluid bg-info footer mt-5 pt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-md-3">
                    <div class="footer-light-text">
                        <img src="<?php echo base_url($result['logo']); ?>" class="img-fluid mb-3" alt="">
                        <p><?php echo $result['en_hakkimizda'] ?></p>
                        <div class="d-flex">
                            <a class="me-4" href="<?php echo $result['facebook'] ?>"><i class="fab fa-facebook-f"></i></a>
                            <a class="me-4" href="<?php echo $result['twitter'] ?>"><i class="fab fa-twitter"></i></a>
                            <a class="me-4" href="<?php echo $result['instagram'] ?>"><i class="fab fa-instagram"></i></a>
                            <a class="me-4" href="<?php echo $result['linkedin'] ?>"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-9 footer-link">
                    <div class="row">
                        <div class="col-md-3">
                            <h5 class="mb-4 footer-white-text"><?php echo $this->lang->line('ft_kurumsal'); ?></h5>
                            <ul class="list-unstyled">
                                <li><a href="<?php echo linkto('hakkimizda') ?>"><?php echo $this->lang->line('ft_kurumsal_1'); ?></a></li>
                                <li><a href="<?php echo linkto('tarihce') ?>"><?php echo $this->lang->line('ft_kurumsal_2'); ?></a></li>
                                <li><a href="<?php echo linkto('firmalar') ?>"><?php echo $this->lang->line('hd_firmalar'); ?></a></li>
                                <li><a href="<?php echo linkto('heyet') ?>"><?php echo $this->lang->line('ft_kurumsal_3'); ?></a></li>
                                <li><a href="<?php echo linkto('yonetim') ?>"><?php echo $this->lang->line('ft_kurumsal_4'); ?></a></li>
                                <li><a href="<?php echo linkto('denetim') ?>"><?php echo $this->lang->line('ft_kurumsal_5'); ?></a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h5 class="mb-4 footer-white-text"><?php echo $this->lang->line('ft_hizmet'); ?></h5>
                            <ul class="list-unstyled">
                                <?php foreach ($hizmet as $value) { ?>
                                    <li><a href="<?php echo base_url('hizmetdetay/' . $value['slug']); ?>"><?php echo $value['baslik']; ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h5 class="mb-4 footer-white-text"><?php echo $this->lang->line('ft_mevzuat'); ?></h5>
                            <ul class="list-unstyled">
                                <li><a href="<?php echo linkto('4562-sayili-osb-kanunu') ?>"><?php echo $this->lang->line('ft_mevzuat_1'); ?></a></li>
                                <li><a href="<?php echo linkto('osb-uygulama-yonetmeligi') ?>"><?php echo $this->lang->line('ft_mevzuat_2'); ?></a></li>
                            </ul>
                        </div>
                        <div class="col-md-3">
                            <h5 class="mb-4 footer-white-text"><?php echo $this->lang->line('ft_iletisim'); ?></h5>
                            <ul class="list-unstyled">
                                <li><a href="tel:<?php echo $result['tel1'] ?>"><i class="fa fa-phone-alt me-3"></i><?php echo $result['tel1'] ?></a></li>
                                <li><a href="tel:<?php echo $result['tel2'] ?>"><i class="fa fa-phone-alt me-3"></i><?php echo $result['tel2'] ?></a></li>
                                <li><a href="mailto:<?php echo $result['mail'] ?>"><i class="fa fa-envelope me-3"></i><?php echo $result['mail'] ?></a></li>
                                <li><a href="#"><i class="fa fa-map-marker-alt me-3"></i><?php echo $result['adres'] ?></a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-white">
        <div class="text-center p-4">
            <span>&copy; Copyright 2022 <?php echo $this->lang->line('haklar'); ?>.</span>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>