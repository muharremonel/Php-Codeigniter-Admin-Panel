<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>
    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/navheader'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider haberler-bg">
        <div class="text-center p-4">
            <div class="mt-4">
                <h1><?php echo $this->lang->line('contact_nasil'); ?></h1>

            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- İletişim Formu -->
    <section class="container" style="margin-top: -80px;">
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow p-4 img-ms">
                    <div class="card-body">
                        <form action="<?php echo base_url('home/contact_send'); ?>" method="POST">
                            <div class="row">
                                <?php echo flashread() ?>
                                <div class="col">
                                    <label for="" class="mb-2"><?php echo $this->lang->line('contact_ad'); ?></label>
                                    <input type="text" class="form-control form-input-d" name="name" aria-label="First name">
                                </div>
                                <div class="col">
                                    <label for="" class="mb-2">Email</label>
                                    <input type="text" class="form-control form-input-d" name="mail" aria-label="Last name">
                                </div>
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="exampleFormControlTextarea1" class="form-label"><?php echo $this->lang->line('contact_mesaj'); ?></label>
                                <textarea class="form-control form-input-d" name="mesaj" id="exampleFormControlTextarea1" rows="3"></textarea>
                            </div>
                            <div class="mb-3 mt-4 text-end">
                                <input type="submit" value="<?php echo $this->lang->line('contact_gonder'); ?>" class="btn btn-gkosb-green-round btn-lg">
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 map-bot">
                <div>
                    <iframe class="position-relative w-100" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d24163.695421489083!2d29.562783!3d40.795842!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xcf9cdb6844fff517!2sGlobal%20Karma%20OSB!5e0!3m2!1str!2str!4v1670834127620!5m2!1str!2str" frameborder="0" style="min-height: 396px; border:0; border-radius: 20px;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
    </section>
    <!-- iletişim Formu Son -->

    <!-- Harita -->
    <section>

    </section>
    <!-- Harita Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>