<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>
    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/navheader'); ?>
    <!-- HEADER INCLUDE SON -->

    <!-- Header Start -->
    <div class="container-fluid mb-5 abo-slider haberler-bg">
        <div class="text-center p-4">
            <div>
                <h1><?php echo $this->lang->line('ana_firma'); ?></h1>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Firmalar -->
    <section class="container">
        <div class="row ref-top">
            <?php foreach ($firma as $value) { ?>
                <div class="col-md-3 p-4">
                    <div class="card shadow p-4 card-ms" style="height: 230px;">
                        <div class="card-body">
                            <a href="<?php echo $value['link']; ?>">
                                <img src="<?php echo base_url($value['gorsel']); ?>" class="w-100 mb-4 ref-img " alt="">
                                <div class="text-center text-dark text-bold mt-5 mb-3">
                                    <span><?php echo $value['name']; ?></span>
                                </div>
                            </a>
                        </div>
                    </div>

                </div>
            <?php } ?>
        </div>
    </section>
    <!-- Firmalar Son -->

    <!-- FOOTER INCLUDE -->
    <?php $this->load->view('front/include/footer'); ?>
    <!-- FOOTER INCLUDE SON -->

    <!-- SCRIPTS INCLUDE -->
    <?php $this->load->view('front/include/scripts'); ?>
    <!-- SCRIPTS INCLUDE SON -->
</body>

</html>