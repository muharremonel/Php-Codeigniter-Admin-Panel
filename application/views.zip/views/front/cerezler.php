<!DOCTYPE html>
<html lang="en">

<!-- HEAD INCLUDE -->
<?php $this->load->view('front/include/head'); ?>
<!-- HEAD INCLUDE SON -->

<body>

    <!-- HEADER INCLUDE -->
    <?php $this->load->view('front/include/header'); ?>
    <!-- HEADER INCLUDE SON -->

    <section>
        <div class="text-center mb-5">
            <h1><?php echo $this->lang->line('cerez_bas1'); ?></h1>
        </div>
    </section>

    <section>
        <div class="container">
            <p class="mb-2">
                <?php echo $this->lang->line('cerez_met'); ?>
            </p>

            <p class="mb-2">
                1. <?php echo $this->lang->line('cerez_mad1'); ?>
            </p>

            <p class="mb-2">
                2. <?php echo $this->lang->line('cerez_mad2'); ?>
            </p>
            <p class="mb-2">
                3. <?php echo $this->lang->line('cerez_mad3'); ?>
            </p>

            <p class="mb-2">
                4. <?php echo $this->lang->line('cerez_mad4'); ?>
            </p>

            <p class="mb-2">
                5. <?php echo $this->lang->line('cerez_mad5'); ?>
            </p>

            <p class="mb-2">
                6. <?php echo $this->lang->line('cerez_mad6'); ?>
            </p>

            <p class="mb-2">
                7. <?php echo $this->lang->line('cerez_mad7'); ?>
            </p>
            <p class="mb-2">
                8. <?php echo $this->lang->line('cerez_mad8'); ?>
            </p>

            <p class="mb-2">
                9. <?php echo $this->lang->line('cerez_mad9'); ?>
            </p>

            <p class="mb-2">
                10. <?php echo $this->lang->line('cerez_mad10'); ?>
            </p>

            <p class="mb-2">
                11. <?php echo $this->lang->line('cerez_mad11'); ?>
            </p>
            <p class="mb-2">
                12. <?php echo $this->lang->line('cerez_mad12'); ?>

            </p>

            <p class="mb-4">
                13. <?php echo $this->lang->line('cerez_mad13'); ?>

            </p>

            <h3 class="mb-3">
                <?php echo $this->lang->line('cerez_cok_bas'); ?>
            </h3>
            <p class="mb-2">
                <?php echo $this->lang->line('cerez_cok_met1'); ?>
            </p>

            <p class="mb-2">
                <?php echo $this->lang->line('cerez_cok_met2'); ?>
            </p>
            <p class="mb-2">
                <?php echo $this->lang->line('cerez_cok_met3'); ?>
            </p>
            <p class="mb-2">
                <?php echo $this->lang->line('cerez_cok_met4'); ?>
            </p>
            <p class="mb-5">
                <?php echo $this->lang->line('cerez_cok_met5'); ?>
            </p>

        </div>

        <!-- FOOTER INCLUDE -->
        <?php $this->load->view('front/include/footer'); ?>
        <!-- FOOTER INCLUDE SON -->

        <!-- SCRIPTS INCLUDE -->
        <?php $this->load->view('front/include/scripts'); ?>
        <!-- SCRIPTS INCLUDE SON -->
</body>

</html>